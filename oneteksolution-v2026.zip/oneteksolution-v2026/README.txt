# oneteksolution-v2026

Ready-to-upload static website package for One Tek Solution.

## Files
- index.html
- catalogue.html
- ic-components.html
- style.css
- script.js

## Upload on GitHub
1. Open your GitHub repository: oneteksolution-v2026
2. Click Add file > Upload files
3. Upload all files from this folder
4. Commit changes
5. Go to Settings > Pages
6. Select Branch: main and Folder: /root
7. Save
