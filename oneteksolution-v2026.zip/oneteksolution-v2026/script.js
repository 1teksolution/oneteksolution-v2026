
function toggleMenu(){
  document.getElementById('menu').classList.toggle('show');
}
function searchPart(){
  const q=document.getElementById('partSearch')?.value.trim();
  if(!q){alert('Please enter part number / product name');return;}
  const msg=`Hello One Tek Solution, I need quotation/details for: ${q}`;
  window.open(`https://wa.me/918505807245?text=${encodeURIComponent(msg)}`,'_blank');
}
function filterCards(type){
  document.querySelectorAll('[data-cat]').forEach(card=>{
    card.style.display = (type==='all' || card.dataset.cat===type) ? '' : 'none';
  });
  document.querySelectorAll('.filter-row button').forEach(b=>b.classList.remove('active'));
  event.target.classList.add('active');
}
